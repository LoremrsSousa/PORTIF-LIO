nome = input('Digite seu nome: ')
print(int(nome))
#ESTÁ DANDO ERRO POR QUE o nome da variavél  é string e não dá para transformar em inteiro
    #ESSE ERRO CHAMA ValueError
    # O CÓDIGO CORRETO

#nome = input('Digite seu nome: ')
#print(nome)