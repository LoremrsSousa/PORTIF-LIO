def soma(num, num2):
    somanum = num + num2
    print(somanum

#ESTÁ DANDO ERRO POR QUE FALTA ALGO NO CÓDIGO
    #ESSE ERRO CHAMA SyntaxError
    #O ERRO NO CÓDIGO É A FALTA DO FECHAMENTO PARÊNTESES ')'
    # O CÓDIGO CORRETO

    #def soma(num, num2):
     #   somanum = num + num2
      #  print(somanum)