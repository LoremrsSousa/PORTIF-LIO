fruta = "Uva"
num = 10
soma = fruta + num

#ESTÁ DANDO ERRO POR QUE não da para somar dois tipos diferentes
    #ESSE ERRO CHAMA TypeError
    # O CÓDIGO CORRETO
#num1 = 10
#num2 = 10
#soma = num1 + num2
#print(soma)