class Animal():
    def _init_(self, nome, idade):
        self.nome = nome
        self.idade = idade

Peixe = Animal("Peixe", 17)
print(Peixe.nome)
print(Peixe.idade)
print(Peixe.cor)

#ESTÁ DANDO ERRO POR QUE o nome da variavél  é string e não dá para transformar em inteiro
    #ESSE ERRO CHAMA AttributeError
    # O CÓDIGO CORRETO

#class Animal():
 #   def _init_(self, nome, idade,cor):
  #      self.nome = nome
   #     self.idade = idade

#Peixe = Animal("Peixe", 17,rosa)
#print(Peixe.nome)
#print(Peixe.idade)
#print(Peixe.cor)