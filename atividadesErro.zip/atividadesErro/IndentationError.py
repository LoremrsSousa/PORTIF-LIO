num = 10
if num % 2 == 0:
print('é divisivel por 2 ')

#ESTÁ DANDO ERRO POR QUE não está identado corretamente
    #ESSE ERRO CHAMA IndentationError
    # O CÓDIGO CORRETO

#num = 10
#if num % 2 == 0:
 #print('é divisivel por 2 ')