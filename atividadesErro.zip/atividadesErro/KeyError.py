NomesCor = {"Lorena":"castanho","Nalice":"loira","Julia":"preto"}
print(NomesCor["Laura"])

#ESTÁ DANDO ERRO POR QUE não tem a chave pedida no print
    #ESSE ERRO CHAMA KeyError
    # O CÓDIGO CORRETO

#NomesCor = {"Lorena":"castanho","Nalice":"loira","Julia":"preto"}
#print(NomesCor["Lorena"])

