Numeros = [1,2,3,4,5,6,7,8]
print(Numero)

#ESTÁ DANDO ERRO POR QUE o nome da variavél foi digitado incorretamente
    #ESSE ERRO CHAMA NameError
    # O CÓDIGO CORRETO

#Numeros = [1,2,3,4,5,6,7,8]
#print(Numeros)