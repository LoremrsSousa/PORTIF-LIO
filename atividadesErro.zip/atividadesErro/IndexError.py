num = ["1","2","3"]
print(num[0])
print(num[3])
#ESTÁ DANDO ERRO POR QUE  está tentando colocar uma posisão que não existe
    #ESSE ERRO CHAMA IndexError
    # O CÓDIGO CORRETO
#num = ["1","2","3","4"]
#print(num[0])
#print(num[3])