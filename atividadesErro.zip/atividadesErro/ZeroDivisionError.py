num1 = int(input('Digite um numero: '))
num2 = int(input('Digite o número 0 : '))
divisao = num1 / num2
#ESTÁ DANDO ERRO POR QUE não tem como dividir por zero
    #ESSE ERRO CHAMA ZeroDivisionError
    # O CÓDIGO CORRETO

#num1 = int(input('Digite um numero: '))
#num2 = int(input('Digite um número  : '))
#if num2 != 0:
 #   divisao = num1 / num2
  #  print('O resultado da divisão é:', divisao)
#else:
 #   print('Não é possível dividir por zero. Por favor, escolha outro número.')