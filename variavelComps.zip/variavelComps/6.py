meuuConjunto = {1,2,3,4,5}
meuuConjunto.remove(3)
print(meuuConjunto)