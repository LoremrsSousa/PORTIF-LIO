#cada vez q eu imprimir ele fica aleatorio, ele não é ordenado
#nao tem final
#ADD = adicionar

#FrutaTupla = ('Maça','Banana','Abacaxi','Uva')
#FrutaLista = ['Maça','Banana','Abacaxi','Uva']
#FrutaConjunto = {'Maça','Banana','Abacaxi','Uva'}


#para unir
frutaConj = {'maça','banana', 'morango', 'uva'}
frutaConj2= {'maça', 'laranja', 'morango', 'pera'} #nao da p ter dois items,se for igual ele dx so um
print(frutaConj)
frutaTotal=frutaConj.union(frutaConj2)


frutaInter=frutaConj.intersection(frutaConj2) #coloca so oq apareceu mais de uma vez


frutaDif=frutaConj2.difference(frutaConj2) #aparece os  sao diferentes,os q aparecem uma vez

#como converter uma lista em conjunto

numeros=[1,2,3,4,5,6,7,8,9,1,2,4]
print(numeros)
numerosConj=set(numeros)
numeros2 = list(numerosConj)
print(numerosConj)


#verificar se tenho no conj

if 'maça' in frutaConj:
    print('Fruta encontrada')
else:
   print('Fruta n encontrada')


#elemina dois numeros iguais(palavras tbm)

#remover os num duplicados

num=(1,2,3,4,5,6,7,8,9,3,4,5,7,8,9)
unicos= set(num)
print(unicos)