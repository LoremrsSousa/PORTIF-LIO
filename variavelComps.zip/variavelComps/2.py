conjunto_a = {1, 2, 3, 4}
conjunto_b = {3, 4, 5, 6}
uniao = conjunto_a.union(conjunto_b)
intersection = conjunto_a.intersection(conjunto_b)
difference = conjunto_a.difference(conjunto_b)
print(uniao)
print(intersection)
print(difference)