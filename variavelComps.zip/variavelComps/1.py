meu_conjunto ={3,5,7 ,"Python"}
print(meu_conjunto)