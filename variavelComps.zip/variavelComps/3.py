meu_conjunto ={3,5,7 ,"Python"}
if "Python" in meu_conjunto:
    meu_conjunto.remove("Python")
    print(meu_conjunto)
else:
    print("Não tem isso no conjunto")