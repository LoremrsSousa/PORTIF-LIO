minha_lista = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4]
conjunto = set(minha_lista)
resultante = list(conjunto)
print(resultante)