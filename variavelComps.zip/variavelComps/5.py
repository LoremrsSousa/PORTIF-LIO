meu_conjunto = {1, 2, 3}
meu_conjunto.add(4)
meu_conjunto.add(5)
meu_conjunto.add(6)
print(meu_conjunto)