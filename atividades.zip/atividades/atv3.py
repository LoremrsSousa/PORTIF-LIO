num = int(input('Digite um número inteiro: '))
if num > 0:
    print('positivo')
elif num == 0:
    print('igual a zero!')
else:
    print('negativo')