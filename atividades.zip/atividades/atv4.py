for num in range(0,11,2):
    print(num)