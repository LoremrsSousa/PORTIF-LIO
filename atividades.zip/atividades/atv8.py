nomeid = {'Nalice':16,'Julia':17}
escolhido = input("Escolha um nome: ")

for v,k in nomeid.items():
    if v == escolhido:
        print(k)