frutas=('morango','banana','pera','maracuja','banana')
fruta = str(input('Digie o nome de alguma fruta:'))

if fruta in frutas:
    print('essa fruta tem')

else :
    print('Essa fruta não tem')