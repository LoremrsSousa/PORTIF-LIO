base = int(input('digite a base: '))
altura = int(input('digite a altura: '))
area = base * altura
print(area)