nome = input('Digite seu nome: ')
idade = int(input('Digite sua idade: '))
print(f'Seu nome é {nome} e sua é {idade}')